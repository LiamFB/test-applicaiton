import { getAllNotifications, addNotifications, markAsRead } from "../src/handlers/notifications.handler";
import { Notification } from "../src/model/notifications";

describe('Notificaton CRUD', () => {
    it('get all notfications for a given post', async () => {
        //TODO setup json/datbase for testing
        expect(true).toBeFalsy();
    })

    it('it should add a like to a feed of a notificaton', async () => {
        expect(true).toBeFalsy();


    })
    it('it should add a comment to a feed of a notificaton', async () => {
        expect(true).toBeFalsy();

    })
    it('A notification feed should have the ablity to be marked as read', async () => {
        expect(true).toBeFalsy();

    })
})