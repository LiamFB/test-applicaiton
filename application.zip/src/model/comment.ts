export interface Comment {
    "id": string,
    "commentText": string
}